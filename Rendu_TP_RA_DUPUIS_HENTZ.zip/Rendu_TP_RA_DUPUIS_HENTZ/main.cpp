//
//  main.cpp
//
//  Created by Jean-Marie Normand on 12/02/13.
//  Copyright (c) 2013 Centrale Nantes. All rights reserved.
//


#include <Windows.h>
#include <GL/GL.h>
#include <GL/glut.h>
#include <GL/glext.h>
#include <iostream>
#include "jpeglib.h"
#include "jerror.h"

// Main include
#include "main.h"
using namespace std;

int score;

int rand_id;
int rand_trap;
int forbidden_id; // don't allow traps to choose the id where the player has its hand when poping


bool pop_new_mole = true;
bool pop_trap = false;
bool active_trap = false;


// Initializing OpenGL/GLUt states
void initGL(int argc, char * argv[]) {
   
   // Setting window's initial position
   glutInitWindowPosition(0, 0);
   // Setting initial window's size: initialized with the size of the video
   glutInitWindowSize(widthFrame,heightFrame);
   
   // Setting up display mode
   glutInitDisplayMode( GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE );
   // Creating window and setting its name
   g_hWindow = glutCreateWindow( "AruCo" );
   // setting up draw callback
   glutDisplayFunc( doWork );
   // Setting up idle callback
   glutIdleFunc( idle );
   // Setting up resize callback
   glutReshapeFunc( resize );
   // Setting up the mouse callback
   glutMouseFunc( mouse );
   // Setting up keyboard callback
   glutKeyboardFunc( keyboard );
   
   // Setting up clear color
   glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
   // and depth clear value
   glClearDepth( 1.0 );
   
   glShadeModel (GL_SMOOTH);
   glEnable(GL_NORMALIZE);
   
   glEnable(GL_CULL_FACE);
   glCullFace(GL_BACK);
}

// Resize function
void resize(GLsizei iWidth, GLsizei iHeight) {
   // Calling ArUco resize
   arucoManager->resize(iWidth, iHeight);
   
   // not all sizes are allowed. OpenCV images have padding
   // at the end of each line in these that are not aligned to 4 bytes
   if (iWidth*3%4!=0) {
      iWidth+=iWidth*3%4;//resize to avoid padding
   }
   glutReshapeWindow(iWidth, iHeight);
   glutPostRedisplay();
}

// Mouse function
void mouse(int b,int s,int x,int y) {
   // nothing for now
}

// Keyboard function
void keyboard(unsigned char key, int x, int y) {
   switch (key) {
      case KEY_ESCAPE:
         exitFunction();
         exit(0);
         break;

      default:
         break;
	}
	
}

// Loop function
void doWork() {

   // Showing images
   //imshow(windowNameCapture, curImg);

	// If it's time to pop a new mole, choose a new id for its marker
   if(pop_new_mole){

	   rand_id = (rand() %4) + 5;
	   pop_new_mole = false;

	   if( rand_id == rand_trap ) // then disable the trap
		   active_trap = false;

   }

   // Same for traps, but it cant be positionned on the mole's marker
   if(pop_trap){

	   do{
		   	   rand_trap = (rand() %4) + 5;
	   }while(rand_trap == rand_id || rand_trap == forbidden_id);
	   
	   active_trap = true; // we declare that there is an active trap
	   pop_trap = false;
   }

   // Calling ArUco draw functions
   arucoManager->displayScore(score);
   arucoManager->drawScene(rand_id, rand_trap, active_trap);

   // If we hit a trap while it's active, disable it but bring score back to 0
   if( arucoManager->moleHit(rand_trap) && active_trap ){
	   active_trap = false;
	   score = 0;
   }

   // If we hit a mole, increase score and pop a new one... but also a potential new trap!
   if( arucoManager->moleHit(rand_id) ){

		pop_new_mole = true;

		forbidden_id = rand_id;

		if( rand()%100 < 30)
			pop_trap = true;

		score++;
   }
   
   // Swapping GLUT buffers
   glutSwapBuffers();
}

// Idle function
void idle() {
   
   // Clearing color and depth buffers
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
   
   // Getting current frames
   cap >> curImg;
   
   // Calling ArUco idle
   arucoManager->idle(curImg);
    
   // Keyboard manager + waiting for key
   char retKey = cv::waitKey(1);
   if(retKey == KEY_ESCAPE){
      exitFunction();
      exit(EXIT_SUCCESS);
   }
  
   // Redisplay GLUT window
   glutPostRedisplay();
}


// Exit function
void exitFunction() {  
   
   // Destroy OpenCV window
   destroyWindow(windowNameCapture);
   
   // Release capture
   cap.release();
   
   // Deleting ArUco manager
   if(arucoManager) {
      delete(arucoManager);
      arucoManager = NULL;
   }
   
   // Deleting GLUT window
   if(g_hWindow) {
      glutDestroyWindow(g_hWindow);
   }
   
}

// Main 
int main(int argc, char * argv[])
{
	srand(time(0));
   // OpenGL/GLUT Initialization
   glutInit(&argc, argv);
   
   // print a welcome message, and the OpenCV version
   printf ("Welcome to arucoMinimal, using OpenCV version %s (%d.%d.%d)\n",
           CV_VERSION,
           CV_MAJOR_VERSION, CV_MINOR_VERSION, CV_SUBMINOR_VERSION);
   
   printf("Hot keys: \n"
          "\tESC - quit the program\n");
   
   // Creating the ArUco object
   arucoManager = new ArUco("camera.yml", 0.105f);
   std::cout<<"ArUco OK"<<std::endl;
   
   // Creating the OpenCV capture
   cout << "Entrez l'identifiant de la camera" << endl;
   cin >> cameraID;
   cap.open(cameraID);
   if(!cap.isOpened()) {
      cerr << "Erreur lors de l'initialisation de la capture de la camera !"<< endl;
      cerr << "Fermeture..." << endl;
      exit(EXIT_FAILURE);
   }
   else{
      // retrieving a first frame so that the display does not crash
      cap >> curImg;
   }
   
   // Getting width/height of the image
   widthFrame  = cap.get(CV_CAP_PROP_FRAME_WIDTH);
   heightFrame = cap.get(CV_CAP_PROP_FRAME_HEIGHT);
   std::cout<<"Frame width = "<<widthFrame<<std::endl;
   std::cout<<"Frame height = "<<heightFrame<<std::endl;
   
   // OpenCV window
   windowNameCapture = "Scene";
   cv::namedWindow(windowNameCapture, CV_WINDOW_AUTOSIZE);  
   
   // Exit function
   atexit(exitFunction);
   
   // OpenGL/GLUT Initialization
   initGL(argc, argv);
   
   // Starting GLUT main loop
   glutMainLoop();
   
   return 0;
}

