// TP_RA_prg1.cpp�: d�finit le point d'entr�e pour l'application console.
//

#include "Windows.h"
#include <iostream>
#include <cstdlib>
#include <string.h>

// OpenCV core module (matrices, etc.)
#include <opencv2/core/core.hpp>
// OpenCV highgui: user interface, windows, etc.
#include <opencv2/highgui/highgui.hpp>
// OpenCV image processing (converting to grayscale, etc.)
#include <opencv2/imgproc/imgproc.hpp>

#include <aruco.h>

// the ASCCI code for the escape key
#define ESC_KEY 27

using namespace std;
using namespace cv;
using namespace aruco;

int main(int argc, char* argv[])
{
	//-------------------------------------------------------------------------1ST TEST: SINGLE IMAGE---------------------------------------------------------------------------------

   // the (default) name of the image file
   String imName = "markers/test0.png";  //ou "markers.jpg" 

   // If we give an argument then open it instead of the default image
   if(argc == 2) {
      imName = argv[1];
   }

   // Reading the image (and forcing it to grayscale)
   Mat im;
   im = imread(imName,IMREAD_GRAYSCALE);
   
   if(!im.data || im.empty() || (im.rows == 0)|| (im.cols == 0)) {
      cout << "Could not load image !" << endl;
      cout << "Exiting now..." << endl;
	  cout << "Expected argument is: [imName]" << endl;
      return 1;
   }

    MarkerDetector myDetector;
	vector<Marker> markers;
	myDetector.detect(im, markers);

	for (unsigned int i = 0; i <markers.size() ; i++){
		cout << markers[i];
		markers[i].draw(im, Scalar(0 , 0 , 255), 2);
	}

	imshow("test",im);
	int key = waitKey(0);
	destroyWindow("test");

	//-------------------------------------------------------------------------VIDEO CAPTURE---------------------------------------------------------------------------------

	// Declaring a VideoCapture object
	// it can open a camera feed
	// or a video file if there is a codec on the machine
	VideoCapture cap;

	int cam_nbr = 0;
	while( !cap.isOpened() && cam_nbr != -1 ){

		cout << "Which cam to open? \n " << endl;
		cin >> cam_nbr;

		if( cam_nbr == -1 )
			return -1;

		cap.open(cam_nbr);

	}
	cout << "Camera " << cam_nbr << " up and running!" << endl;

	float freq = 30.0; //in Hz

	Mat image;
	Mat gray_image;

	MarkerDetector capDetector;
	vector<Marker> capmarkers;

	string windowName = "Aruco test";
	namedWindow(windowName, CV_WINDOW_AUTOSIZE);

	key = 0;

	while( key != ESC_KEY ){

		key = waitKey(1000.0/freq);

		// Getting the new image from the camera
		cap >> image; //or:  cap.read(image);

		cvtColor( image, gray_image, CV_RGB2GRAY );

		capDetector.detect(gray_image, capmarkers);

		for (unsigned int i = 0; i <capmarkers.size() ; i++){
			//cout << capmarkers[i];
			capmarkers[i].draw(gray_image, Scalar(0 , 0 , 255), 2);
		}

		imshow(windowName, gray_image);
	}

	// Destroying the windows
	destroyWindow(windowName);

	// Releasing the video capture
	cap.release();
	
   	return 0;
}

